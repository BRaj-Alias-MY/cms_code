using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using cms.dtos;
using cms.Models;
using cms.Services;
using Microsoft.AspNetCore.Mvc;
//using cms.Models; 
using AutoMapper;
using Microsoft.AspNetCore.Http;
namespace cms.Controllers {
    [Route ("api/[controller]")]
    public class CompanyController : ControllerBase {
        private ICompanyRepository _companyRepository;
        private readonly IMapper _mapper;
        public CompanyController (ICompanyRepository companyRepository, IMapper mapper) {
            _companyRepository = companyRepository ??
                throw new ArgumentNullException (nameof (companyRepository));
            _mapper = mapper;
        }

        [HttpPost]

        [Route ("getAllCompanies")]
        [ProducesResponseType (typeof (Entities.McsCompanies), 200)]
        public async Task<IActionResult> GetAllCompanies () {

            var companyEntities = await _companyRepository.GetCompanies ();
            if (companyEntities == null) {
                return NotFound ();
            }
            return Ok (companyEntities);

        }

        [HttpPost]
        [Route ("getCompany")]
        [ProducesResponseType (typeof (Entities.McsCompanies), 200)]
        public async Task<IActionResult> GetCompany ([FromBody] CompanyInput company) {
            var companyEntity = await _companyRepository.GetCompany (company.CompanyId);
            if (companyEntity == null) {
                return NotFound ();
            }
            return Ok (companyEntity);
        }

        [HttpPost]
        [Route ("showCompaniesByEntity")]
        [ProducesResponseType (typeof (dtos.CompanyDto), 200)]
        public async Task<IActionResult> GetCompaniesByCompanyMapper () {
            var companyEntity = await _companyRepository.GetCompanies ();
            var data = _mapper.Map<List<CompanyDto>> (companyEntity);
            return Ok (data);
        }

        [HttpPost]
        [Route ("createCompany")]
        public async Task<IActionResult> CreateCompany ([FromBody] Entities.McsCompanies company) {
            var companyExists = await _companyRepository.CompanyIfExists (company.CompanyCode);
            if (companyExists > 0) {
                return Ok ("Already Exists!");
            } else {
                await _companyRepository.AddCompany (company);
                await _companyRepository.SaveChanges ();
            }
            return Ok (company);
        }

        [HttpPost]
        [Route ("updateCompany")]
        public async Task<IActionResult> UpdateCompany ([FromBody] Entities.McsCompanies company) {

            await _companyRepository.UpdateCompany (company);
            return Ok (company);

        }

        [HttpPost]
        [Route ("deactivateCompany")]
        public async Task<IActionResult> DeactivateCompany ([FromBody] CompanyInput company) {
            int result = 0;
            var companyId = company.CompanyId;
            result = await _companyRepository.DeActivateCompany (companyId);
            return Ok (result);
        }

        [HttpPost]
        [Route ("checkCompanyExists")]
        public async Task<IActionResult> CheckCompanyExists ([FromBody] CompanyInput company) {
            int result = 0;
            var company_code = company.CompanyCode;
            result = await _companyRepository.CompanyIfExists (company_code);
            return Ok (result);
        }

    }
}