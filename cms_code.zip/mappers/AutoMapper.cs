using System;
using System.Collections.Generic;
using AutoMapper;
using cms.Entities;
namespace cms.dtos {
    public class AutoMapperProfile : Profile {
        public AutoMapperProfile () {
            CreateMap<McsCompanies, CompanyDto> ();
        }
    }
}